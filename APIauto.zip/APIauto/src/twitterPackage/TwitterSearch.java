package twitterPackage;

import org.testng.annotations.Test;
import static io.restassured.RestAssured.given;

import java.io.FileInputStream;

import java.io.IOException;
import java.util.Properties;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class TwitterSearch 
{
	Properties prop;
	Logger l=Logger.getLogger("TwitterSearch");
	
	@Test
	public void SearchTweet() throws IOException
	{
		prop=new Properties();
		PropertyConfigurator.configure("C:\\New folder\\APIauto\\Log4j.properties");
		FileInputStream fis = new FileInputStream("C:\\New folder\\APIauto\\src\\twitterPackage\\data.properties");
		prop.load(fis);
		RestAssured.baseURI="https://api.twitter.com/1.1/search/";
		Response res = given().auth().oauth(prop.getProperty("ConsumerKey"),prop.getProperty("ConsumerSecret"),prop.getProperty("Token"),prop.getProperty("TokenSecret")).
		queryParam("q","Qualitest")
		.when().get("/tweets.json").then().extract().response();
		
		String response = res.asString();
		System.out.println("Response = "+response);
		l.info(response);
		
		
	}
}

