package twitterPackage;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.given;

import java.io.FileInputStream;

import java.io.IOException;
import java.util.Properties;

import io.restassured.path.json.JsonPath;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class HashTags 
{
	Properties prop;
	Logger l=Logger.getLogger("HashTags");
	@Test
	public void hashLocation() throws IOException
	{
		prop=new Properties();
		PropertyConfigurator.configure("C:\\New folder\\APIauto\\Log4j.properties");
		FileInputStream fis = new FileInputStream("C:\\New folder\\APIauto\\src\\twitterPackage\\data.properties");
		prop.load(fis);
		RestAssured.baseURI="https://api.twitter.com/1.1/trends/";
		Response res = given().auth().oauth(prop.getProperty("ConsumerKey"),prop.getProperty("ConsumerSecret"),prop.getProperty("Token"),prop.getProperty("TokenSecret")).
		//queryParam("id","23424848").
		
		when().get("/available.json").then().assertThat().statusCode(200).contentType(ContentType.JSON).extract().response();
		
		
		
		String response = res.asString();
		
		JsonPath js = new JsonPath(response);
		
		
		int count = js.get("size()");
		for(int i=0;i<count;i++)
		{
			String country=js.get("["+i+"].name").toString();
			if(country.equalsIgnoreCase(prop.getProperty("HashCountry")))
			{
				String id=js.get("["+i+"].parentid").toString();
				Response res1=given().auth().oauth(prop.getProperty("ConsumerKey"),prop.getProperty("ConsumerSecret"),prop.getProperty("Token"),prop.getProperty("TokenSecret")).
				param("id",id).
				when().get("/place.json").then().assertThat().statusCode(200).contentType(ContentType.JSON).extract().response();
				
				String Response1=res1.asString();
				
				JsonPath js1=new JsonPath(Response1);
				int count1=js1.get("["+0+"].trends.size()");
				
				for(int j=0;j<count1;j++)
				{
					String hashTag=js1.getString("["+0+"].trends["+j+"].name");
					String Original=js1.getString("["+0+"].trends["+j+"]").toString();
					
					if(hashTag.charAt(0)=='#' && j<=5)
					{
						System.out.println("Original - "+Original);
						l.info(Original);
					}
					
				}
				
				break;
			}
		}
	}
}
