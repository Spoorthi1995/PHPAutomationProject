package twitterPackage;

import org.testng.annotations.Test;
import static io.restassured.RestAssured.given;

import java.io.FileInputStream;
//import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import io.restassured.path.json.JsonPath;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class Twitter 
{
	Properties prop;
	Logger l=Logger.getLogger("Twitter");
	
	//get tweet
	@Test
	public void getTweet() throws IOException
	{
		prop=new Properties();
		PropertyConfigurator.configure("C:\\New folder\\APIauto\\Log4j.properties");
		FileInputStream fis = new FileInputStream("C:\\\\New folder\\\\APIauto\\\\src\\\\twitterPackage\\\\data.properties");
		prop.load(fis);
		RestAssured.baseURI = "https://api.twitter.com/1.1/statuses/";
		Response res = given().auth().oauth(prop.getProperty("ConsumerKey"),prop.getProperty("ConsumerSecret"),prop.getProperty("Token"),prop.getProperty("TokenSecret")).
		param("count","1").when().get("/home_timeline.json").then().extract().response();	
		
		String response = res.asString();                                                 
		System.out.println(response);
		
		//to get id and text
		JsonPath js = new JsonPath(response);
		l.info(response);
		
		String id = js.get("id").toString();
		l.info(id);
		
		String text = js.get("text").toString();
		l.info(text);
		
		System.out.println("Id - "+id);
		System.out.println("text - "+text);
		
	}
	
	
	
}

