package twitterPackage;

import org.testng.annotations.Test;
import static io.restassured.RestAssured.given;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import io.restassured.path.json.JsonPath;
import io.restassured.RestAssured;
import io.restassured.response.Response;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class PostTweet 
{
	Properties prop;
	Logger l=Logger.getLogger("PostTweet");
	
	//post tweet
	@Test
	public void postTweet() throws IOException
	{
		prop=new Properties();
		PropertyConfigurator.configure("C:\\New folder\\APIauto\\Log4j.properties");
		FileInputStream fis = new FileInputStream("C:\\New folder\\APIauto\\src\\twitterPackage\\data.properties");
		prop.load(fis);
		RestAssured.baseURI = "https://api.twitter.com/1.1/statuses/";
		Response res = given().auth().oauth(prop.getProperty("ConsumerKey"),prop.getProperty("ConsumerSecret"),prop.getProperty("Token"),prop.getProperty("TokenSecret")).
		queryParam("status","Welcome API message QualitestS").
		when().post("/update.json").then().extract().response();
		
		String response = res.asString();
		System.out.println(response);
		
		JsonPath js = new JsonPath(response);
		l.info(response);
		
		String id = js.get("id").toString();
		System.out.println("Id - "+id);
		l.info(id);
		
		String text = js.get("text").toString();
		System.out.println("text - "+text);  
		l.info(text);
		                            
	}
	
}
