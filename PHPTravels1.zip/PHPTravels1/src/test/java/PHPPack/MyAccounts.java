package PHPPack;
import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import org.testng.asserts.SoftAssert;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class MyAccounts extends BaseClass
{
	WebDriver driver;
	Properties prop;
	public static Logger l=Logger.getLogger("MyAccounts");
	
	public MyAccounts(WebDriver driver)
	{
		this.driver=driver;
	}
	By MyProfileBtn = By.xpath("//a[contains(text(),'My Profile')]");
	By MyAccEmail = By.xpath("//input[@placeholder='Email']");
	By MyAccPass = By.xpath("//input[@placeholder='Password']");
	By MyAccConfirmPass = By.xpath("//input[@placeholder='Confirm Password']");
	By MyAccAddress = By.xpath("//input[@placeholder='Address']");
	By MyAccAddress2 = By.xpath("//input[@placeholder='Address 2']");
	By MyAccCity = By.xpath("//input[@placeholder='City']");
	By MyAccState = By.xpath("//input[@placeholder='State/Region']");
	By MyAccZipCode = By.xpath("//input[@placeholder='Postal/Zip Code']");
	By MyAccCountry = By.xpath("//span[contains(text(),'Select Country')]");
	By MyAccCountryPlace = By.xpath("//input[@class='chosen-search-input']");
	By MyAccPhone = By.xpath("//input[@placeholder='Phone']");
	By MyAccSubmitBtn = By.xpath("//button[@class='btn btn-block updateprofile btn-primary']");
	
	By WishlistBtn = By.xpath("//a[contains(text(),'Wishlist')]");
	By CurrencyBtn = By.xpath("//div[@class='dropdown dropdown-currency']//a[@id='dropdownCurrency']");
	
	
	By LangBtn = By.xpath("//a[@id='dropdownLangauge']");

	
	
	
	public void MyAccountProfilePage() throws Exception
	{
		prop = new Properties();
		PropertyConfigurator.configure("C:\\Users\\Online Test\\git\\PHPAutomationProject\\PHPTravels1\\Log4j.properties");
		FileInputStream fis = new FileInputStream("C:\\Users\\Online Test\\git\\PHPAutomationProject\\PHPTravels1\\src\\test\\java\\PHPPack\\data.properties");
		prop.load(fis);
		
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		driver.findElement(MyProfileBtn).click();
		driver.findElement(MyAccEmail).clear();
		driver.findElement(MyAccEmail).sendKeys("kajor@s.com");
		driver.findElement(MyAccPass).sendKeys("kajo@123");
		driver.findElement(MyAccConfirmPass).sendKeys("kajor@123");
		driver.findElement(MyAccAddress).sendKeys("#15, 2nd cross, WhiteRoad");
		driver.findElement(MyAccAddress2).sendKeys("#2, 3rd Cross, WhiteRoad");
		driver.findElement(MyAccCity).sendKeys("Poolcity");
		driver.findElement(MyAccState).sendKeys("California");
		driver.findElement(MyAccZipCode).sendKeys("700590");
		driver.findElement(MyAccCountry).click();
		driver.findElement(MyAccCountryPlace).sendKeys("United States");
		driver.findElement(MyAccCountryPlace).sendKeys(Keys.ENTER);
		driver.findElement(MyAccPhone).clear();
		driver.findElement(MyAccPhone).sendKeys("9900887766");
		
		/*driver.findElement(WishlistBtn).click();
		
		
		driver.findElement(CurrencyBtn).click();
		driver.findElement(By.linkText("EUR")).click();
		
		
		driver.findElement(LangBtn).click();
		driver.findElement(By.linkText("Russian")).click();*/

		//driver.findElement(MyAccSubmitBtn).click();
		
		String title=driver.getTitle();
		l.error("Submit button not working");
		
		SoftAssert sa=new SoftAssert();
		sa.assertEquals(title,"My Account");
		sa.assertAll();
		
		File src = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(src, new File("C:\\PHP\\MyAccounts"));
	}
}
