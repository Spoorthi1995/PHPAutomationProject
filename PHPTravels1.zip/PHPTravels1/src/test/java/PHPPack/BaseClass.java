package PHPPack;

import java.io.FileInputStream;


import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

@Test
public class BaseClass 
{
	public static WebDriver driver;
	public static Properties prop = new Properties();

	public  static void  LaunchDriverBrowser() throws Exception
	{
		
		System.setProperty("webdriver.chrome.driver","C:\\chrome driver\\chrome78\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		FileInputStream fis = new FileInputStream("C:\\Users\\Online Test\\git\\PHPAutomationProject\\PHPTravels1\\src\\test\\java\\PHPPack\\data.properties");
		prop.load(fis);
		driver.get(prop.getProperty("PHPURL"));

		
		
		driver.findElement(By.xpath("/html[1]/body[1]/div[1]/header[1]/div[1]/div[1]/div[1]/div[2]/div[1]/ul[1]/li[3]/div[1]/a[1]")).click();

		
	
		
	}
	
	
	
	
}
