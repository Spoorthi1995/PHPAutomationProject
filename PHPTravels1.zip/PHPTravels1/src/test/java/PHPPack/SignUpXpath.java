package PHPPack;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.asserts.SoftAssert;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class SignUpXpath extends BaseClass
{
	WebDriver driver;
	Properties prop;
	public static Logger l=Logger.getLogger("SignUpXpath");
	public SignUpXpath(WebDriver driver)
	{
		this.driver = driver;
	}
	By FirstName = By.xpath("//input[@placeholder='First Name']");
	By LastName = By.xpath("//input[@placeholder='Last Name']");
	By MobileNumber = By.xpath("//input[@name='phone']");
	By Email = By.xpath("//input[@name='email']");
	By Password = By.xpath("//input[@type=\"password\"]");
	By ConfirmPassword = By.xpath("//input[@placeholder='Confirm Password']");
	//By Cookie = By.xpath("//button[@id='cookyGotItBtn']");
	By SignUpBtn = By.xpath("//button[@class='signupbtn btn_full btn btn-success btn-block btn-lg']");
	//By Cookie = By.xpath("//button[@class='cc-btn cc-dismiss']");

	
	public void RegistrationPage() throws Exception
	{
		prop = new Properties();
		PropertyConfigurator.configure("C:\\Users\\Online Test\\git\\PHPAutomationProject\\PHPTravels1\\Log4j.properties");
		FileInputStream fis = new FileInputStream("C:\\Users\\Online Test\\git\\PHPAutomationProject\\PHPTravels1\\src\\test\\java\\PHPPack\\data.properties");
		prop.load(fis);
		
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		//driver.findElement(Cookie).click();
		driver.findElement(FirstName).sendKeys(prop.getProperty("FirstName"));
		driver.findElement(LastName).sendKeys(prop.getProperty("LastName"));
		driver.findElement(MobileNumber).sendKeys(prop.getProperty("MobileNumber"));
		driver.findElement(Email).sendKeys(prop.getProperty("Email"));
		driver.findElement(Password).sendKeys(prop.getProperty("Password"));
		driver.findElement(ConfirmPassword).sendKeys(prop.getProperty("ConfirmPassword"));
		driver.findElement(SignUpBtn).sendKeys(Keys.ENTER);
		
		String title=driver.getTitle();
		l.info(title);
		
		SoftAssert sa=new SoftAssert();
		sa.assertEquals(title,"Register");
		sa.assertAll();
		
		File src = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(src, new File("C:\\PHP\\SignUp"));
	}
}
