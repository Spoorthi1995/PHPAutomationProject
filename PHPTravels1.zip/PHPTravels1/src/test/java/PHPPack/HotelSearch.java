package PHPPack;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import org.testng.asserts.SoftAssert;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class HotelSearch extends BaseClass
{
	WebDriver driver;
	Properties prop;
	public static Logger l=Logger.getLogger("HotelSearch");
	
	public HotelSearch(WebDriver driver)
	{
		this.driver = driver;
	}
	By Cookie = By.xpath("//button[@id='cookyGotItBtn']");
	By HotelBtn = By.xpath("//a[@class='text-center hotels active']");
	By SearchHotelorCity = By.xpath("//span[contains(text(),'Search by Hotel or City Name')]");
	By SearchHotelorCityType = By.xpath("//div[@id='s2id_autogen1']//a[@class='select2-choice']");
	
	By CitySelect = By.xpath("//div[contains(text(),'aysia, Malasia')]");
	By CheckInDate = By.xpath("//input[@id='checkin']");
	By CheckOutDate = By.xpath("//input[@id='checkout']");
	//By Guests = By.xpath("//input[@id='htravellersInput']");
	By AddAdults = By.xpath("//div[contains(@class,'col o2')]//button[contains(@class,'btn btn-white bootstrap-touchspin-up')][contains(text(),'+')]");
	By AddChildren = By.xpath("//div[contains(@class,'col 01')]//button[contains(@class,'btn btn-white bootstrap-touchspin-up')][contains(text(),'+')]");
	By SubmitBtn = By.xpath("//div[@class='col-md-2 col-xs-12 o1']//button[@class='btn btn-primary btn-block'][contains(text(),'Search')]");
	
	
	public void SuccessHotelSearch() throws IOException, InterruptedException
	{
		prop = new Properties();
		PropertyConfigurator.configure("C:\\Users\\Online Test\\git\\PHPAutomationProject\\PHPTravels1\\Log4j.properties");
		FileInputStream fis = new FileInputStream("C:\\Users\\Online Test\\git\\PHPAutomationProject\\PHPTravels1\\src\\test\\java\\PHPPack\\data.properties");
		prop.load(fis);
		
		driver.manage().timeouts().implicitlyWait(2,TimeUnit.SECONDS);
		//driver.findElement(Cookie).click();
		driver.findElement(HotelBtn).click();
		Thread.sleep(1000);
		driver.findElement(SearchHotelorCity).click();
		//driver.findElement(SearchHotelorCityType).click();
		driver.manage().timeouts().implicitlyWait(2,TimeUnit.SECONDS);
		driver.findElement(SearchHotelorCityType).sendKeys("mal");
		driver.findElement(CitySelect).click();
		driver.findElement(CheckInDate).click();
		
		
		//for selecting check in date
		while(!driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/nav[1]/div[2]")).getText().contains("November"))
		{
			driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/nav[1]/div[3]/*")).click();
			break;
		}
		int count = driver.findElements(By.xpath("//div[1]//div[1]//div[1]//div[2]//div[26]")).size();
		System.out.println(count);
		for(int i=0;i<count;i++)
		{
			String text = driver.findElements(By.xpath("//div[1]//div[1]//div[1]//div[2]//div[26]")).get(i).getText();
			if(text.equalsIgnoreCase("21"))
			{
				driver.findElements(By.xpath("//div[1]//div[1]//div[1]//div[2]//div[26]")).get(i).click();
			}
		}
		
		driver.findElement(CheckOutDate).click();
		
		while(!driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[2]/nav[1]/div[2]")).getText().contains("November"))
		{
			driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[2]/nav[1]/div[3]/*")).click();
			break;
		}
		
		int count1 = driver.findElements(By.xpath("/html[1]/body[1]/div[2]/div[2]/div[1]/div[1]/div[2]/div[33]")).size();
		for(int i=0;i<count1;i++)
		{
			String text = driver.findElements(By.xpath("/html[1]/body[1]/div[2]/div[2]/div[1]/div[1]/div[2]/div[33]")).get(i).getText();
			if(text.equalsIgnoreCase("28"))
			{
				driver.findElements(By.xpath("/html[1]/body[1]/div[2]/div[2]/div[1]/div[1]/div[2]/div[33]")).get(i).click();
			}
		}
		
		driver.findElement(AddAdults).click();
		driver.findElement(AddChildren).click();
		driver.findElement(SubmitBtn).click();
		
		String title=driver.getTitle();
		l.error("Result page not shown prperly");
		
		SoftAssert sa=new SoftAssert();
		sa.assertEquals(title,"Hotels Results");
		sa.assertAll();
		
		File src = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(src, new File("C:\\PHP\\Hotel"));
		 
		
		
	}
	
}
