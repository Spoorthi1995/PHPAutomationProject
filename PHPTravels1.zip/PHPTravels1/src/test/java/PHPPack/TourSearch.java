package PHPPack;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.asserts.SoftAssert;

public class TourSearch extends BaseClass
{

	WebDriver driver;
	Properties prop;
	public static Logger l=Logger.getLogger("TourSearch");
	
	public TourSearch(WebDriver driver)
	{
		this.driver = driver;
	}
	//By Cookie = By.xpath("//button[@id='cookyGotItBtn']");
	By TourBtn = By.xpath("//a[contains(text(),'Tours')]");
	By SelectCity = By.xpath("//span[contains(text(),'Search by Listing or City Name')]");
	By SelectCityType = By.xpath("//a[contains(@class,'select2-choice select2-default')]");
	
	By SelectCityPlace = By.xpath("//div[contains(text(),'Big Bus Tour of Dubai')]");
	By TypeOfTour = By.xpath("//span[contains(text(),'Select')]");
	
	By TypeOfTourTitle = By.xpath("//li[contains(text(),'Holidays')]");
	
	By DepartureDtae = By.xpath("//input[@id='DateTours']");
	By GuestsAdultsPlus = By.xpath("//div[contains(@class,'col-md-12')]//button[contains(@class,'btn btn-white bootstrap-touchspin-up')][contains(text(),'+')]");

	By SearchBtn = By.xpath("//*[@id=\"tours\"]/div/div/form/div/div/div[4]/button");
	public void SuccessTourSearch() throws IOException, InterruptedException
	{
		prop = new Properties();
		PropertyConfigurator.configure("C:\\Users\\Online Test\\git\\PHPAutomationProject\\PHPTravels1\\Log4j.properties");
		FileInputStream fis = new FileInputStream("C:\\Users\\Online Test\\git\\PHPAutomationProject\\PHPTravels1\\src\\test\\java\\PHPPack\\data.properties");
		prop.load(fis);
		
		driver.manage().timeouts().implicitlyWait(2,TimeUnit.SECONDS);
		//driver.findElement(Cookie).click();
		driver.findElement(TourBtn).click();
		driver.findElement(SelectCity).click();
		driver.findElement(SelectCityType).sendKeys(Keys.DOWN);
		Thread.sleep(1000);
		driver.findElement(SelectCityPlace).click();
		
		driver.findElement(TypeOfTour).click();

		driver.findElement(TypeOfTourTitle).click();
		
		driver.findElement(DepartureDtae).click();
		
		while(!driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[6]/nav[1]/div[2]/i[1]")).getText().contains("November"))
		{
			driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[6]/nav[1]/div[3]/*")).click();
			break;
		}
		Thread.sleep(1000);
		int count = driver.findElements(By.xpath("/html[1]/body[1]/div[2]/div[6]/div[1]/div[1]/div[2]/div[35]")).size();
		
		for(int i=0;i<count;i++)
		{
			String text = driver.findElements(By.xpath("/html[1]/body[1]/div[2]/div[6]/div[1]/div[1]/div[2]/div[35]")).get(i).getText();
			if(text.equalsIgnoreCase("30"))
			{
				driver.findElements(By.xpath("/html[1]/body[1]/div[2]/div[6]/div[1]/div[1]/div[2]/div[35]")).get(i).click();
			}
		}
		driver.findElement(GuestsAdultsPlus).click();
		Thread.sleep(1000);
		driver.findElement(SearchBtn).click();
		
		String title=driver.getTitle();
		l.info("Success result page");
		
		SoftAssert sa=new SoftAssert();
		sa.assertEquals(title,"Big Bus Tour of Dubai");
		sa.assertAll();
		
		File src = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(src, new File("C:\\PHP\\Tours"));
	}

	

}
