package PHPPack;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.asserts.SoftAssert;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class LoginPage extends BaseClass
{
	WebDriver driver;
	Properties prop;
	public static Logger l=Logger.getLogger("LoginPage");
	
	public LoginPage(WebDriver driver)
	{
		this.driver = driver;
	}
	//By Cookie = By.xpath("//button[@id='cookyGotItBtn']");
	By Email = By.xpath("//input[@placeholder='Email']");
	By Password = By.xpath("//input[@placeholder='Password']");
	By LoginBtn = By.xpath("//button[@class='btn btn-primary btn-lg btn-block loginbtn']");
	
	public void ExistingUserLogin() throws IOException
	{
		prop = new Properties();
		PropertyConfigurator.configure("C:\\Users\\Online Test\\git\\PHPAutomationProject\\PHPTravels1\\Log4j.properties");
		FileInputStream fis = new FileInputStream("C:\\Users\\Online Test\\git\\PHPAutomationProject\\PHPTravels1\\src\\test\\java\\PHPPack\\data.properties");
		prop.load(fis);
		
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		//driver.findElement(Cookie).click();
		driver.findElement(Email).sendKeys(prop.getProperty("LoginEmail"));
		driver.findElement(Password).sendKeys(prop.getProperty("LoginPassword"));
		driver.findElement(LoginBtn).click();
		
		String title=driver.getTitle();
		l.info(title);
		
		SoftAssert sa=new SoftAssert();
		sa.assertEquals(title,"Login");
		sa.assertAll();
		
		File src = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(src, new File("C:\\PHP\\Login"));
		
	}
}
