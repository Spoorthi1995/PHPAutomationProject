package Test;
import java.io.IOException;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import PHPPack.BaseClass;
import PHPPack.TourSearch;

public class TestTourSearch extends BaseClass
{
	@Test
	public void CheckTours() throws IOException, InterruptedException
	{
		TourSearch ts1 = new TourSearch(driver);
		ts1.SuccessTourSearch();
		driver.close();
	}
}
