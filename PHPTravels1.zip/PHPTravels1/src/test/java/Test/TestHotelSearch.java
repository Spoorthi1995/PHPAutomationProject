package Test;
import java.io.IOException;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import PHPPack.BaseClass;
import PHPPack.HotelSearch;

public class TestHotelSearch extends BaseClass
{
	@Test
	public void CheckHotels() throws IOException, InterruptedException
	{
		HotelSearch hs1 = new HotelSearch(driver);
		hs1.SuccessHotelSearch();
		
		driver.close();
	}
}
