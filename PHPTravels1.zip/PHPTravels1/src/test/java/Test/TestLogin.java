package Test;
import java.io.IOException;

import org.openqa.selenium.By;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import PHPPack.BaseClass;
import PHPPack.LoginPage;


public class TestLogin extends BaseClass
{
	@Test
	public void checkLogin() throws IOException
	{
		driver.findElement(By.xpath("//a[@class='dropdown-item active tr']")).click();
		LoginPage lp = new LoginPage(driver);
		lp.ExistingUserLogin();
		
		driver.close();
	}
}
