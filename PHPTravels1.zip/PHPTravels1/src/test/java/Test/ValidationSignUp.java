package Test;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import PHPPack.BaseClass;
import PHPPack.SignUpXpath;



public class ValidationSignUp extends BaseClass
{
	@Test
	public void CheckSignup() throws Exception
	{
		driver.findElement(By.xpath("//a[@class='dropdown-item tr']")).click();
		SignUpXpath su=new SignUpXpath(driver);
		su.RegistrationPage();	
		driver.manage().timeouts().implicitlyWait(2,TimeUnit.SECONDS);
		driver.close();
	}
}
