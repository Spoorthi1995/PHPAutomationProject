package Test;


import org.openqa.selenium.By;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import PHPPack.BaseClass;
import PHPPack.LoginPage;
import PHPPack.MyAccounts;

public class TestMyAccounts extends BaseClass
{
	
	@Test
	public void checkMyAccount() throws Exception
	{
		driver.findElement(By.xpath("//a[@class='dropdown-item active tr']")).click();
		LoginPage lp = new LoginPage(driver);
		lp.ExistingUserLogin();

		MyAccounts ms=new MyAccounts(driver);
		ms.MyAccountProfilePage();
		
		driver.close();
	}
}
